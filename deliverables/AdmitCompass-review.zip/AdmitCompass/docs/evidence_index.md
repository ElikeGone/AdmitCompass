# Evidence index: rubric requirement → actual artifact

Status as of 2026-10-23 (Step 7). "Exists" means I opened and checked the file. The official rubric is in `docs/rubric/official_requirements.md`.

| Rubric row (pts) | Required evidence | Artifact(s) | Status |
|---|---|---|---|
| Novelty + value (21) | Twist vs ChatGPT; helps real people | `docs/product_spec.md`; `experiments/source_audit.json`; **competitor comparison: not done** | Partial |
| App works (15) | Working end-to-end run | `experiments/agent_runs/20261023T180104Z_fixture-tech-pm-india/` (+ `verification.json`); `deliverables/screenshots/04–07` | Exists |
| Staff can run it (5) | ≤10-min fresh clone | README setup; **fresh-clone timed test: not done** | Pending |
| Look + feel (10) | UI screenshots | `deliverables/screenshots/` (8 + README) | Exists |
| Motivation + what's new (8) | Problem cost; alternatives incl. ChatGPT | **Sourced problem statistics: not collected; ChatGPT comparison: not done** | Pending |
| Agent design (10) | Roles, tools, handoffs, models, one real run with screenshots | `docs/decisions.md` (ADR-007, 010, 012); `experiments/agent_runs/RUN_LOG.md`; `deliverables/screenshots/07_results_trace.png`; **diagram: not made** | Mostly exists |
| Tokenomics (8) | Measured input/cached/output per run; costs at scale; cost-cutting + trade-off | `experiments/tokenomics/tokenomics_analysis.md/.json` (real tokens); `experiments/tokenomics/optimization_comparison.md/.json` (−29% requests, −30% est. tokens, quality preserved); **price unknown → hypothetical scenarios only** | Exists (cost = hypothetical) |
| Safety (8) | Injection, malfunction, overspend; ≥1 defense shown working | `experiments/safety/safety_test_matrix.md/.json` (24/24 pass); `tests/test_safety.py`; real budget stop in `experiments/agent_runs/20261023T175556Z…`; fail-closed run `…174645Z…` | Exists |
| Impact + metrics (5) | Quantified benefit; real user quote or before/after time | `experiments/performance/performance_metrics.md` (local timings only); `docs/user_test_protocol.md`; **user sessions: none yet** | **Pending; half-points cap risk** |
| Report design (2) | `report.html` | Not started (Step 8+) | Pending |
| Slides (6+2) | `slides.html` | Not started | Pending |

## Supporting files
- Real-run log and caveats: `experiments/agent_runs/RUN_LOG.md`
- Model compatibility evidence: `experiments/smoke_test/`
- Source collection audit: `experiments/source_audit.json`
- Tests: `tests/` (124 passed, 1 live test skipped; see README)

## Proposed paid experiment (NOT run; needs approval)
**Goal:** a clean fresh-generation measurement of the optimized orchestrator, which closes the cache-replay caveat and validates the mock-based saving on provider-reported tokens.
- **Input:** fictional applicant B (`data/fixtures/applicant_energy_finance.json`). It has never been sent, so no response cache can be hit.
- **Runs:** exactly 1 full analysis with the optimized orchestrator (current default).
- **Budget cap:** 20 requests / 200,000 tokens / 300 s (existing hard limits). Expected about 12–16 requests and 90k–130k input tokens, based on the real run and the mock comparison.
- **Produces:** a second complete real trace (different career and budget: energy finance, Texas, $100k per year), fresh per-agent latency and tokens, and a second demo result for the UI.
- **Not a strict A/B test:** a different profile from run 1, so the reduction is indicative. A strict A/B would need 2 fresh runs (baseline + optimized) on a new third profile, about 2× the cost.
