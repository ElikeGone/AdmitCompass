# Rubric Tracker

Official source: [docs/rubric/official_requirements.md](rubric/official_requirements.md). Total 100 points.
Status values: `pending` / `in progress` / `verified` (verified = the evidence file was opened and checked).
**Evidence rule:** any row missing its required evidence is capped at half points.

Last inspected: 2026-10-23 (Step 9B: 28 programs with sourced facts, link audit, colour; 170 tests). Earlier, Step 10: 4.0 visual reset of homepage + Explore, `deliverables/screenshots/v4/`, 155 tests). Earlier, Step 9: homepage + Explore v3, screenshots in `deliverables/screenshots/v3/`, 154 tests). Earlier, Step 8: v2 redesign, discovery tier with 24 programs, 151 tests, `deliverables/screenshots/v2/`). Earlier, Step 7: safety matrix 24/24, tokenomics + optimization, performance; see `docs/evidence_index.md`). Step 6: web app, 8 screenshots. Earlier, Step 5: complete run `20261023T180104Z`, audit ok. Earlier in Step 5: Added agents and orchestrator, 78 mocked tests, `experiments/agent_runs/` (3 real attempts: 2 rejected at request 1, 1 stopped by the budget; no complete trace yet). Earlier, Step 4: Added: `data/programs/programs.json`, `experiments/source_audit.json` (49/78 fields verified), `tests/test_programs.py` (48 tests total pass). Earlier, Step 3: Supporting evidence so far: `experiments/smoke_test/` (1 real call, real token counts) and `tests/test_foundation.py` (19 passing). No rubric row is complete yet.

| # | Criterion | Pts | Required evidence | Implementation plan | Evidence location | Status |
|---|---|---|---|---|---|---|
| 1 | Novelty + real-world value | 21 | Clear twist vs. ChatGPT/existing tools; evidence it helps real people (aims at Tier 3) | Career-first matching + evidence-gated STEM/sponsorship + Skeptic + two-tier discovery (verified vs needs-verification); competitor test of same prompts in ChatGPT | `experiments/competitor_comparison/`, report §3, `data/discovery/` | in progress (evidence-gated dataset built, see `experiments/source_audit.json`; competitor test not run) |
| 2 | App works | 15 | End-to-end run on demo profiles without errors; real outputs | 4-agent pipeline, FastAPI, UI; golden-profile tests | `tests/`, `deliverables/screenshots/` | in progress (web app working locally against the saved real run; 96 tests; live run from the UI not exercised with a paid call) |
| 3 | Teaching staff can run it | 5 | Fresh clone → running in ≤10 min; `.env` loaded from repo then parent | `.env` loader, one-command start, fresh-clone dry run timed | `experiments/fresh_clone_test.md` | in progress (loader unit-tested for parent `.env`; fresh-clone test not run) |
| 4 | Look + feel | 10 | Polished UI screenshots; clear evidence cards & trace | Single-page app: intake → results tabs → evidence → trace | `deliverables/screenshots/v2/` | in progress (v2 hybrid redesign after real product feedback; 9 genuine screenshots incl. mobile; browser-tested at 1024/375/320 px; no formal user test yet) |
| 5 | Motivation + what is new | 8 | Who has the problem, cost in money/time/frustration (sourced); alternatives incl. ChatGPT compared | Cited stats + competitor comparison table | report §2–3, `experiments/competitor_comparison/` | pending |
| 6 | Agent design | 10 | Roles, tools, handoffs diagram, models + why, one real step-by-step run with screenshots | Trace viewer + exported trace JSON | report §4, `experiments/agent_runs/` | in progress (complete real trace + UI trace screenshot `07_results_trace.png`; agent diagram still needed) |
| 7 | Tokenomics | 8 | **Measured** input/cached/output tokens per run; cost per run, per user/month, at 100 & 10k users; cost-cut experiment + trade-off | Token logger from API `usage`; baseline vs optimized runs | `experiments/tokenomics/` | in progress (real per-agent tokens + retry overhead + cache analysis; cost-cut experiment −29% requests / −30% est. tokens with quality preserved; **price unknown → hypothetical $ only**; no fresh real run of the optimized path) |
| 8 | Safety | 8 | Injection/misuse, malfunctions, overspending covered; **≥1 defense shown working** | Injection tests on intake & evidence text; schema/claim validator; per-run cost cap | `tests/test_safety.py`, `experiments/safety/` | in progress (**24/24 red-team scenarios pass**, `experiments/safety/safety_test_matrix.md`; 6 vulnerabilities found and fixed; real budget stop + fail-closed runs on file) |
| 9 | Impact + metrics | 5 | Quantified benefit with sources; **real user quote or before/after time** | Timed baseline (manual research vs app) + 1–3 real-user sessions | `experiments/user_testing/`, `docs/user_test_protocol.md` | pending (protocol + form ready; **0 sessions**; local performance metrics exist) |
| 10 | Report design | 2 | Self-contained `report.html`, 10–15 printed pages, sections in exact order, images embedded | Build script embeds images as base64 | `deliverables/report.html` | pending |
| 11 | Slides content | 6 | ≤10 slides covering suggested order | reveal.js deck from report content | `deliverables/slides.html` | pending |
| 12 | Slides design | 2 | Clean, self-contained, images embedded, reveal.js CDN | Same embed script | `deliverables/slides.html` | pending |

## Non-graded but required submission items
| Item | Location | Status |
|---|---|---|
| Public GitHub repo (or private + `zlisto`) | — | pending |
| README.md with step-by-step setup | `README.md` | in progress (Step 3 commands verified locally; app run steps pending) |
| `.env.example`, no real values | `.env.example` | in progress (updated Step 2; not yet tested) |
| Small test dataset + switch instructions | `data/` | in progress (6-program dataset is itself small; noted in README) |
| Optional 2–3 min demo video | `deliverables/` | pending |

- 2026-10-23 Step 10: Career Intelligence dashboard added (deterministic API, 10 new tests, 181 total); see experiments/dashboard/validation_report.md.
